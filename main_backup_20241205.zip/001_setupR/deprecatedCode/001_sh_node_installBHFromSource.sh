# Installing BH from source.
# Trying to install flowCore for flow_Cytometry data and am having problems install cytolib, one of the dependencies. 
# A github repo suggested that BH 1.75 would solve the issue.
# This is just to document the commands I ran after attempting to install cytolib usijg renv.
