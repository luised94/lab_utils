mkdir -p commonplace
touch commonplace/commonplace.rec

