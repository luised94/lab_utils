#!/bin/bash

export R_LIBS_USER=$HOME/R/x86_64-pc-linux-gnu-library/4.2
