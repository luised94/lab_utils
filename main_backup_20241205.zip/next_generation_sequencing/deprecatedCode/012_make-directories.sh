#!/bin/bash
date

mkdir /home/luised94/data/221024Bel_CHIP /home/luised94/data/rscripts /home/luised94/data/rlibs



